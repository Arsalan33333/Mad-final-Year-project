import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PRAYERS = [
  { id: 'fajr', name: 'Fajr' },
  { id: 'dhuhr', name: 'Dhuhr' },
  { id: 'asr', name: 'Asr' },
  { id: 'maghrib', name: 'Maghrib' },
  { id: 'isha', name: 'Isha' },
];

const STORAGE_KEY = '@prayer_tracker_data';

export default function PrayerTrackerScreen() {
  const [prayers, setPrayers] = useState(PRAYERS);
  const [selectedDate, setSelectedDate] = useState(getTodayDateKey());

  // Helper to get today's date as a string key
  function getTodayDateKey() {
    const today = new Date();
    return today.toISOString().split('T')[0];
  }

  // Load data when screen loads
  useEffect(() => {
    loadPrayerData();
  }, []);

  const loadPrayerData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
      const savedData = jsonValue != null ? JSON.parse(jsonValue) : {};
      
      const todaysData = savedData[selectedDate] || {};
      const updatedPrayers = prayers.map(prayer => ({
        ...prayer,
        offered: todaysData[prayer.id] || false,
      }));
      setPrayers(updatedPrayers);
    } catch (e) {
      console.error('Failed to load prayer data', e);
    }
  };

  const togglePrayer = async (prayerId) => {
    try {
      const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
      const savedData = jsonValue != null ? JSON.parse(jsonValue) : {};
      
      // Update state
      const updatedPrayers = prayers.map(prayer => 
        prayer.id === prayerId 
          ? { ...prayer, offered: !prayer.offered }
          : prayer
      );
      setPrayers(updatedPrayers);
      
      // Save to storage
      if (!savedData[selectedDate]) savedData[selectedDate] = {};
      const prayerToUpdate = updatedPrayers.find(p => p.id === prayerId);
      savedData[selectedDate][prayerId] = prayerToUpdate.offered;
      
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(savedData));
    } catch (e) {
      Alert.alert('Error', 'Failed to save prayer data');
    }
  };

  const markAllAs = async (status) => {
    const updatedPrayers = prayers.map(prayer => ({ ...prayer, offered: status }));
    setPrayers(updatedPrayers);

    try {
      const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
      const savedData = jsonValue != null ? JSON.parse(jsonValue) : {};

      if (!savedData[selectedDate]) savedData[selectedDate] = {};
      prayers.forEach(prayer => {
        savedData[selectedDate][prayer.id] = status;
      });

      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(savedData));
    } catch (e) {
      Alert.alert('Error', 'Failed to update all prayers');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Today's Prayers</Text>
      <Text style={styles.date}>{selectedDate}</Text>

      {/* Mark All Buttons */}
      <View style={styles.buttonRow}>
        <TouchableOpacity 
          style={[styles.markButton, styles.markAllOffered]} 
          onPress={() => markAllAs(true)}
        >
          <Text style={styles.markButtonText}>Mark All Offered</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.markButton, styles.markAllNotOffered]} 
          onPress={() => markAllAs(false)}
        >
          <Text style={styles.markButtonText}>Mark All Not Offered</Text>
        </TouchableOpacity>
      </View>

      {/* Prayer List */}
      {prayers.map(prayer => (
        <TouchableOpacity
          key={prayer.id}
          style={[
            styles.prayerItem, 
            { backgroundColor: prayer.offered ? '#4CAF50' : '#f44336' }
          ]}
          onPress={() => togglePrayer(prayer.id)}
        >
          <Text style={styles.prayerName}>{prayer.name}</Text>
          <Text style={styles.statusText}>
            {prayer.offered ? '✓ Offered' : '✗ Not Offered'}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#f5f5f5' 
  },
  title: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    textAlign: 'center', 
    marginTop: 10,
    color: '#333'
  },
  date: {
    fontSize: 16,
    textAlign: 'center',
    color: '#666',
    marginBottom: 20,
  },
  buttonRow: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 25 
  },
  markButton: { 
    padding: 15, 
    borderRadius: 10, 
    flex: 1, 
    marginHorizontal: 5,
    alignItems: 'center'
  },
  markAllOffered: { 
    backgroundColor: '#4CAF50' 
  },
  markAllNotOffered: { 
    backgroundColor: '#F44336' 
  },
  markButtonText: { 
    color: 'white', 
    fontWeight: 'bold', 
    fontSize: 16 
  },
  prayerItem: {
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  prayerName: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: 'white' 
  },
  statusText: { 
    fontSize: 16, 
    color: 'white', 
    fontStyle: 'italic' 
  },
});