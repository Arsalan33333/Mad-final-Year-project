import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@prayer_tracker_data';

export default function ReportsScreen() {
  const [reportType, setReportType] = useState('daily');
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, offered: 0, percentage: 0 });

  useEffect(() => {
    loadReportData();
  }, [reportType]);

  const loadReportData = async () => {
    setLoading(true);
    try {
      const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
      const allData = jsonValue != null ? JSON.parse(jsonValue) : {};
      
      // Convert object to array for display
      const dataArray = Object.keys(allData).map(date => ({
        date,
        prayers: allData[date]
      }));
      
      setReportData(dataArray);
      
      // Calculate basic stats
      if (dataArray.length > 0 && reportType === 'daily') {
        const today = new Date().toISOString().split('T')[0];
        const todayData = allData[today] || {};
        const prayerIds = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
        const offeredCount = prayerIds.filter(id => todayData[id]).length;
        
        setStats({
          total: prayerIds.length,
          offered: offeredCount,
          percentage: Math.round((offeredCount / prayerIds.length) * 100)
        });
      }
    } catch (e) {
      console.error('Failed to load report data', e);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const countOfferedPrayers = (prayersObj) => {
    if (!prayersObj) return 0;
    return Object.values(prayersObj).filter(status => status === true).length;
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Loading report data...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Prayer Reports</Text>
      
      {/* Period Selector */}
      <View style={styles.selectorRow}>
        {['daily', 'weekly', 'monthly'].map(type => (
          <TouchableOpacity
            key={type}
            style={[
              styles.typeButton, 
              reportType === type && styles.activeButton
            ]}
            onPress={() => setReportType(type)}
          >
            <Text style={[
              styles.typeButtonText,
              reportType === type && styles.activeButtonText
            ]}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      {/* Stats Summary */}
      {reportType === 'daily' && (
        <View style={styles.statsContainer}>
          <Text style={styles.statsTitle}>Today's Summary</Text>
          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{stats.offered}/{stats.total}</Text>
              <Text style={styles.statLabel}>Prayers Offered</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{stats.percentage}%</Text>
              <Text style={styles.statLabel}>Completion</Text>
            </View>
          </View>
        </View>
      )}
      
      {/* Report List */}
      <ScrollView style={styles.reportContainer}>
        <Text style={styles.sectionTitle}>
          {reportType === 'daily' ? 'Daily History' : 
           reportType === 'weekly' ? 'Weekly Report' : 'Monthly Report'}
        </Text>
        
        {reportData.length > 0 ? (
          reportData.slice(0, 10).map((item, index) => (
            <View key={index} style={styles.reportItem}>
              <View style={styles.reportHeader}>
                <Text style={styles.reportDate}>{formatDate(item.date)}</Text>
                <Text style={styles.prayerCount}>
                  {countOfferedPrayers(item.prayers)}/5 prayers
                </Text>
              </View>
              
              {/* Prayer Status Dots */}
              <View style={styles.prayerDots}>
                {['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map((prayer, idx) => {
                  const isOffered = item.prayers && item.prayers[prayer.toLowerCase()];
                  return (
                    <View key={idx} style={styles.prayerDotContainer}>
                      <View 
                        style={[
                          styles.prayerDot,
                          { backgroundColor: isOffered ? '#4CAF50' : '#F44336' }
                        ]} 
                      />
                      <Text style={styles.prayerDotLabel}>{prayer.charAt(0)}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No prayer data available yet.</Text>
            <Text style={styles.emptySubtext}>
              Start tracking your prayers on the Tracker tab!
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#f5f5f5' 
  },
  centerContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  loadingText: {
    marginTop: 15,
    fontSize: 16,
    color: '#666',
  },
  title: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    textAlign: 'center', 
    marginTop: 10,
    marginBottom: 20,
    color: '#333'
  },
  selectorRow: { 
    flexDirection: 'row', 
    justifyContent: 'space-around', 
    marginBottom: 25 
  },
  typeButton: { 
    paddingVertical: 12, 
    paddingHorizontal: 25, 
    borderRadius: 25, 
    backgroundColor: '#E0E0E0' 
  },
  activeButton: { 
    backgroundColor: '#4CAF50' 
  },
  typeButtonText: { 
    fontSize: 16, 
    fontWeight: '600', 
    color: '#666' 
  },
  activeButtonText: { 
    color: 'white' 
  },
  statsContainer: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statBox: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  reportContainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  reportItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    marginBottom: 10,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  reportDate: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  prayerCount: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '600',
  },
  prayerDots: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 5,
  },
  prayerDotContainer: {
    alignItems: 'center',
  },
  prayerDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginBottom: 5,
  },
  prayerDotLabel: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 10,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
});