import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// Import screens
import PrayerTrackerScreen from './PrayerTrackerScreen';
import PrayerTimingsScreen from './PrayerTimingsScreen';
import ReportsScreen from './ReportsScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            
            if (route.name === 'Tracker') {
              iconName = focused ? 'checkmark-circle' : 'checkmark-circle-outline';
            } else if (route.name === 'Timings') {
              iconName = focused ? 'time' : 'time-outline';
            } else if (route.name === 'Reports') {
              iconName = focused ? 'stats-chart' : 'stats-chart-outline';
            }
            
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#4CAF50',
          tabBarInactiveTintColor: 'gray',
          headerStyle: { backgroundColor: '#4CAF50' },
          headerTintColor: 'white',
        })}
      >
        <Tab.Screen name="Tracker" component={PrayerTrackerScreen} options={{ title: 'Prayer Tracker' }} />
        <Tab.Screen name="Timings" component={PrayerTimingsScreen} options={{ title: 'Prayer Timings' }} />
        <Tab.Screen name="Reports" component={ReportsScreen} options={{ title: 'Reports' }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}