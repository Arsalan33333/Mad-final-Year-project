import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  ActivityIndicator,
  Alert 
} from 'react-native';

export default function PrayerTimingsScreen() {
  const [timings, setTimings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('Makkah, Saudi Arabia');

  useEffect(() => {
    // Using default location (Makkah) for demonstration
    // In a real app, you would use expo-location here
    fetchPrayerTimes();
  }, []);

  const fetchPrayerTimes = async () => {
    try {
      const today = new Date();
      const dateStr = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;
      setDate(dateStr);

      // Using Al-Adhan API with default coordinates for Makkah
      const response = await fetch(
        `https://api.aladhan.com/v1/timings/${dateStr}?latitude=21.3891&longitude=39.8579&method=2`
      );
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();
      
      if (data.code === 200) {
        setTimings(data.data.timings);
      } else {
        Alert.alert('Error', 'Failed to fetch prayer times from API.');
      }
    } catch (error) {
      console.error('Error fetching prayer times:', error);
      // Fallback static timings in case API fails
      setTimings({
        Fajr: '05:15',
        Sunrise: '06:30',
        Dhuhr: '12:30',
        Asr: '15:45',
        Maghrib: '18:20',
        Isha: '19:45',
        Imsak: '05:05',
        Midnight: '00:30'
      });
      Alert.alert('Info', 'Using sample prayer times. Check your internet connection.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Fetching prayer times...</Text>
      </View>
    );
  }

  const prayerDisplay = [
    { key: 'Fajr', label: 'Fajr' },
    { key: 'Sunrise', label: 'Sunrise' },
    { key: 'Dhuhr', label: 'Dhuhr' },
    { key: 'Asr', label: 'Asr' },
    { key: 'Maghrib', label: 'Maghrib' },
    { key: 'Isha', label: 'Isha' },
    { key: 'Imsak', label: 'Imsak' },
    { key: 'Midnight', label: 'Midnight' },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Prayer Timings</Text>
      <Text style={styles.subtitle}>{location}</Text>
      <Text style={styles.date}>{date}</Text>
      
      {timings ? (
        <View style={styles.timingsContainer}>
          {prayerDisplay.map((prayer) => (
            <View key={prayer.key} style={styles.timingRow}>
              <Text style={styles.prayerName}>{prayer.label}</Text>
              <Text style={styles.prayerTime}>{timings[prayer.key] || '--:--'}</Text>
            </View>
          ))}
        </View>
      ) : (
        <Text style={styles.errorText}>Unable to load prayer times.</Text>
      )}
      
      <View style={styles.noteContainer}>
        <Text style={styles.noteText}>
          Note: Using Makkah coordinates for demo. To use your location, enable expo-location.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#f5f5f5' 
  },
  centerContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  loadingText: {
    marginTop: 15,
    fontSize: 16,
    color: '#666',
  },
  title: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    textAlign: 'center', 
    marginTop: 10,
    color: '#333'
  },
  subtitle: { 
    fontSize: 18, 
    textAlign: 'center', 
    color: '#4CAF50', 
    marginVertical: 10,
    fontWeight: '600'
  },
  date: { 
    fontSize: 16, 
    textAlign: 'center', 
    marginBottom: 25, 
    color: '#666' 
  },
  timingsContainer: { 
    backgroundColor: 'white', 
    borderRadius: 15, 
    padding: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  timingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  prayerName: { 
    fontSize: 18, 
    fontWeight: '600', 
    color: '#333' 
  },
  prayerTime: { 
    fontSize: 18, 
    color: '#4CAF50', 
    fontWeight: '600' 
  },
  errorText: { 
    textAlign: 'center', 
    fontSize: 18, 
    color: 'red', 
    marginTop: 40 
  },
  noteContainer: {
    marginTop: 25,
    padding: 15,
    backgroundColor: '#E8F5E9',
    borderRadius: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  noteText: {
    fontSize: 14,
    color: '#2E7D32',
    fontStyle: 'italic',
  },
});